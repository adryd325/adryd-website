const nbs = require("./nbs.json");
const fs = require("fs");
const fetch = require("node-fetch");

async function run() {
for (a of nbs){
  await fetch(a.download_link).then(res => fs.promises.writeFile("./" + a.name.replace(/\//g, "+")+ ".nbs", res.body))
}}

run()